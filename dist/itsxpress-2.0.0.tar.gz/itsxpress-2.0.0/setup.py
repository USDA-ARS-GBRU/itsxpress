"""setup.py: python package setup for ITSxpress

"""

from setuptools import setup
import subprocess

if __name__ == "__main__":
    setup()

